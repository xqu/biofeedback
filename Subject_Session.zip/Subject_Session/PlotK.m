a=BestKCa('55_2.txt', '55_3.txt');
function k=BestKCa(fileName1, fileName2);
averageMat=[]
for k=6:6:60
    % plot the dependence of predication accuracy on k
    filename = fileName1;
    numClusters = k;
    numRuns = 10;
    vals=[];
    maxMSRO=0;
    for i=[1:numRuns]
        [m,s,r,o,idx,X,sumd,D] = pred_accuracy(fileName2,numClusters);
        msro = min([m,s,r,o]);
        if (msro>maxMSRO)
            maxMSRO = msro;
            maxidx=idx;
            maxX = X;
            maxsumd = sumd;
            maxD =D;
            
        end
        vals = [vals;m s r o msro];
        
    end
    
    %for i=[1:5]
    % subplot(5,1,i);
    %  histogram(vals(:,i),0:1:100);
    % end
    
    averageMat=[averageMat, mean(vals(:,5))];
    
end
disp(averageMat);
plot(6:6:60, averageMat);
title('Relationship between K and Accuracy');
xlabel('Number of CLusters(k)');
ylabel('Accuracy');
max=0;
b=0;
for a=6:6:60;
    
    dy=gradient(averageMat, 6)
    
end
max=dy(1);
d=0;
for i=2:length(dy)
    if max<=dy(i)
        max=dy(i);
        d=i;
    end
end
k=6*d;
disp(k);
end
