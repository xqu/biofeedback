dataset = createDataset(67);

[accuracy,accuracies,best,win] = kmeansCrossoverValidation(dataset,36,1)
