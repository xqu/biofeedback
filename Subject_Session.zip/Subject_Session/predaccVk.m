% plot the dependence of predication accuracy on k
filename = '55_2.txt';
numClusters = 24;
numRuns = 25;
vals=[];
maxMSRO=0;
for i=[1:numRuns]
    [m,s,r,o,idx,X,sumd,D] = pred_accuracy('55_3.txt',numClusters);
    msro = min([m,s,r,o]);
    if (msro>maxMSRO)
        maxMSRO = msro;
        maxidx=idx;
        maxX = X;
        maxsumd = sumd;
        maxD =D;

    end
    vals = [vals;m s r o msro];
    display([i,m,s,r,o,msro]);
end

for i=[1:5]
    subplot(5,1,i);
    histogram(vals(:,i),0:1:100);
end


