function [ classifier, clusters, accuracy, accByLabel ] = kmeansClassify(labels,vals, k )
%kmeansClassify(data,k,N) create a k-means classifier for labelled data 
%   data is a matrix with m+1 cols
%      the first column is an integer label in the range 1:r 
%      the remaining are floats
%   k is the number of clusters if calculates
%   classifier is a kxm+1 matrix of the k clusters for the data
%      the first column is the label for that cluster
%   accuracy is the proportion of the data which is correctly classified
%   accByLabel is a rxr matrix M where M(i,j) is the number of samples
%      in the data with label i that are predicted to be of type j

    
    [clusteredData,clusters,~,~] = kmeans(vals,k);
    % clusteredData is a column vector which gives the cluster id for
    % each row in vals
    
    
    % Lets first find out how many labels there are 
    maxLabel = round(max(labels));
    % then for each cluster, we see which label appears most frequently
    % in that cluster, and we assign that label to that cluster
    % using the classifier vector
    classifier = zeros(1,maxLabel);
    
    for (c=[1:k])
        labelCounts = hist(labels(clusteredData==c),1:maxLabel);
        
        % labelCounts(j) = number of times label j appears in cluster c
        [m,j] = max(labelCounts);
        % j is the label that appears most often in cluster c 
        % and m is the number of times it appears!
        % so j is the label we assign to cluster c for our classifier
        classifier(c)=j;
    end
    
    [accuracy, accByLabel] = clusterPredict([labels,vals],classifier,clusters);
    
    % next we need to calculate the accuracy of this classifier,
    % that is the proportion of classifications that are correct
    classifications = classifier(clusteredData)';
    

    
    %accuracy = sum(labels == classifications)/length(labels);
    
    % we can get a finer measure of the accuracy by calculating the number
    % of times data with label i was classified with label j
    
    %accByLabel = zeros(maxLabel,maxLabel);
    %for i=[1:maxLabel]
    %    accByLabel(i,:) = hist(labels(classifier(clusteredData)==i),[1:maxLabel]);
    %end
    

end

