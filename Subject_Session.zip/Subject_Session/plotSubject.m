column1=input('How many subjects would you like to plot?(e.g 3):');
subjectNumber=ones(1,column1)
for i=1:column1
    subjectNumber(1,i)=input('Please enter the subject number one by one(e.g 55): ')
end


column2=input('How many sessions would you like to plot?(e.g 5):');
sessionNumber=ones(1,column1)
for j=1:column2
    sessionNumber(1,j)=input('Please enter the session number one by one(e.g 5): ')
end
numg=column1*column2;
numg
pos=1;
n=1;

for i=1:column1
    for j=1:column2
        str1=int2str(subjectNumber(1,i));
        str2=int2str(sessionNumber(1,j));
        name=strcat(str1,'_',str2,'.txt')
        
        drawplot(name,numg,pos)
       %for each session, run the drawplot function to get clusters
       %different sessions are using different clusters. 
 %We may consider to save the cluster from the first and apply to others
       %legend('math','relax1','reading','relax2');
       % numg=numg+2;
        pos=pos+1;
        n=n+1;
    
    end
end


function ddd=drawplot(a,numg,pos)
numClusters = 24;

windowSize = 600;

f1 = figure(1);


% Here is the code ..
% read in the data
all = importdata(a,' ',0);
extra = max(1,round((length(all)-12000)/2))
all = all(extra:length(all)-extra,:);
all = all(:,2:21); % throw out the first parameter which is the time in seconds
% select a section of 1000 observations from each
%musePlot(all);  % look at all data, select some


%coreData = [all(600:2400,:);all(3600:5400,:);all(6600:8400,:);all(9600:11400,:)];
% classify 

[idx,X,sumd,D] = kmeans(all,numClusters);

[C,D]=museClassifyAll(all,1,X);

hold off;

%from analysisDemo.m
a1= hist(C(600:2400),0.5:numClusters-0.5);
a2= hist(C(3600:5400),0.5:numClusters-0.5);
a3= hist(C(6600:8400),0.5:numClusters-0.5);
a4= hist(C(9600:11400),0.5:numClusters-0.5);

aa = [a1;a2;a3;a4]';

 vv = (aa' == max(aa'));
 numCC = 4;
 dd = [1:numCC]*vv;
 CC = dd(C);

subplot(numg,1,pos); 
zz1 = clusterWindow(CC,windowSize);

%plot(zz1./(windowSize/100),'markersize', 20);
plot(zz1./(windowSize/100));

%{ 
plot the graph
h = plot(G,'EdgeLabel',G.Edges.Weight,'LineWidth',LWidths)
bb = (aa'./sum(aa'))';
nodecolor=bb(:,1:3);
nodecolor(:,3) = bb(:,1);  % blue for math
nodecolor(:,2) = bb(:,3);  % green for reading
nodecolor(:,1) = bb(:,4);  % red for ClosedEye
nodecolor = (nodecolor'./sum(bb'))';
h.NodeColor = nodecolor;
h.MarkerSize = sum(aa')./(max(max(aa))/20);
h.NodeLabel = sum(aa')
%}

if pos==1
    legend('Math','Shut','Read','Open');
end 

grid on; grid minor;
xticks([0:3000:12000]);
axis([0,12000,0,100])



clusters = [1:numClusters];
mathClusters = clusters(vv(1,:)==1);
shutClusters = clusters(vv(2,:)==1);
readClusters = clusters(vv(3,:)==1);
openClusters = clusters(vv(4,:)==1);

title(a);


B=zeros(numClusters,numClusters);
for i=[1:length(C)-1]
  B(C(i),C(i+1)) = B(C(i),C(i+1))+1;
end


end
