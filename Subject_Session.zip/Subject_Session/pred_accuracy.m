function [math,shut,open,read,idx,X,sumd,D ] = pred_accuracy(filename,k )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

windowSize = 600;
numClusters=k;

% read in the data
all = importdata(filename,' ',0);
extra = max(1,round((length(all)-12000)/2));
all = all(extra:length(all)-extra,:);
all = all(:,2:21);

% classify the data

[idx,X,sumd,D] = kmeans(all,numClusters);

[C,D]=museClassifyAll(all,1,X);

% calculate the specifity of each cluster
% ie how often in appears in math, shut, read, open 

%{
a1= hist(C(600:2400),0.5:numClusters-0.5);
a2= hist(C(3600:5400),0.5:numClusters-0.5);
a3= hist(C(6600:8400),0.5:numClusters-0.5);
a4= hist(C(9600:11400),0.5:numClusters-0.5);
%}

a1= hist(C(1:3000),0.5:numClusters-0.5);
a2= hist(C(3001:6000),0.5:numClusters-0.5);
a3= hist(C(6001:9000),0.5:numClusters-0.5);
a4= hist(C(9001:length(C)),0.5:numClusters-0.5);

aa = [a1;a2;a3;a4]';


% form the 4 meta-clusters, which consist of those k-clusters
% which are most specific for math (resp, shut, read, open)
% vv maps the k-clusters into [1:4] 
 vv = (aa' == max(aa'));
 numCC = 4;
 dd = [1:numCC]*vv;
 CC = dd(C);
 c1= hist(CC(1:3000),0.5:numCC-0.5);
 c2= hist(CC(3001:6000),0.5:numCC-0.5);
 c3= hist(CC(6001:9000),0.5:numCC-0.5);
 c4= hist(CC(9001:length(CC)),0.5:numCC-0.5);
 ccs = [c1;c2;c3;c4]'./30;


% finally we run a sliding window across the data 
% and count how often each activity is predicted within that sliding window

subplot(4,1,4); 
zz1 = clusterWindow(CC,windowSize);

% look into analyzing data using pca(all) to see which
% vectors have the most importance, and cluster on those??
clusters = [1:numClusters];
mathClusters = clusters(vv(1,:)==1);
openClusters = clusters(vv(2,:)==1);
readClusters = clusters(vv(3,:)==1);
closedClusters = clusters(vv(4,:)==1);

% finally we calculate the prediction accuracy for each of the four
% activities

 ww = (zz1'==max(zz1'))';  % this highlights with 1 or 0 which activity has highest prediction
 mathpreds = sum(ww(601:3000,:));
 shutpreds = sum(ww(3601:6000,:));
 readpreds = sum(ww(6601:9000,:));
 openpreds = sum(ww(9601:length(ww),:));
 
math = mathpreds(1)/24;
shut = shutpreds(2)/24;
read = readpreds(3)/24;
open = openpreds(4)/(length(ww)-9600)*100;
end

