%function [all, aa, ccs, zz1, score  ] = predictFourth(filenames,numClusters )
%Training on 3 and testing on the fourth, that would be the most convincing.
% Run the three kmeans to find out the best clusters ,then predict the 4th.
%overview Show main clustering data for the specified file
%   this calls museplot on all 4 electrodes
%   shows the clusters and their specificity for each of the activities
%   show the 4 meta-clusters and their specificity
%   shows the accuracy of prediction over all the data

% example:
% files = {'55_1.txt',  '55_2.txt',  '55_3.txt',  '55_4.txt',  '55_5.txt',
% '56_1.txt',  '56_2.txt',  '56_3.txt',  '56_4.txt',  '56_5.txt', 
%'57_1.txt',  '57_2.txt',  '57_3.txt',  '57_4.txt',  '58_1.txt', 
%'58_2.txt', '58_3.txt',  '59_1.txt',  '59_2.txt',  '59_3.txt'}
% overviewMultiple(files,  36)
% predictFourth(files,  24)
filenames1 = { '55_2.txt',  '55_3.txt',  '55_4.txt'};
filename =  '55_5.txt';
numClusters= 36;
% files = { '59_2.txt',   '59_4.txt',  '59_5.txt'}

windowSize = 600;

% The top plot is the five bands for each of the 4 electrodes

% The second plot is the clusters for each sample

% The third plot is the percentage of a sliding window containing each
% cluster

% The fourth is the number of times that each cluster appears in each of
% the four mental activities, arranged by cluster 

% The fifth is the same number of times that each cluster appears but
% arranged by activity


% Here is the code ..
% read in the data, put all math togehter
read=[];
shut=[];
open=[];
numFiles = length(filenames1);

for i=[1:numFiles]  
    filename = filenames1{i};
    all = importdata(filename,' ',0);
    extra = max(1,round((length(all)-12000)/2));
    all = all(extra:length(all)-extra,:);
    all = all(:,2:21);
    sizes = [size(math);size(shut);size(read);size(open)];
    math = [math;all(1:3000,:)];
    shut = [shut;all(3001:6000,:)];
    read = [read;all(6001:9000,:)];
    open = [open;all(9001:length(all),:)];
end
   
all1 = [math;shut;read;open];

[~,Classify,~,~] = kmeans(all1,numClusters);
% dd= makeprediction(all1,Classify); rename 'dd' to 'predictor';
% 'predictor' tell which activity it going to be in;
% then see how accurate it is, have a function to measure how good it is;
% check the minimum? how often the 'predictor' could be right?
% what percent of the activities is successfully predicted?
% best average or minimum, average is better. random is 25%.
% we get something 60, 70, 
% Read data from the 4th sesssion,
% using average for now, 

all = importdata(filename,' ',0);
    extra = max(1,round((length(all)-12000)/2));
    all = all(extra:length(all)-extra,:);
    all = all(:,2:21);
    sizes = [size(math);size(shut);size(read);size(open)];
    math = [all(1:3000,:)];
    shut = [all(3001:6000,:)];
    read = [all(6001:9000,:)];
    open = [all(9001:length(all),:)];
numFiles=1

%musePlot(all);  % look at all data, select some


% classify 


[C,~]=museClassifyAll(all,1,Classify);
% use the clusters based on the first three sessions.
% for each sample , which cluster it belongs to 

% plot
hold off;

figure(1);

subplot(4,1,1); 
musePlot(all);
%xticks([0:3000:12000])
grid on; grid minor;
legend('alpha','beta','delta','gamma','theta');


subplot(4,1,2); 
% plot of the frequency each cluster appears in each core activity
% i.e. the middle three minutes of each activity
mathMax = 3000*numFiles;
shutMax = 6000*numFiles;
readMax = 9000*numFiles;
openMax = length(all);

%readMax = length(all); %9000*numFiles;
%openMax = length(all);

a1= hist(C(1:mathMax),0.5:numClusters-0.5);
a2= hist(C(mathMax+1:shutMax),0.5:numClusters-0.5);
a3= hist(C(shutMax+1:readMax),0.5:numClusters-0.5);
a4= hist(C(readMax+1:openMax),0.5:numClusters-0.5);

aa = [a1;a2;a3;a4]';
sizeaa = size(aa)
bar(aa./30); legend('math','shut','read','open');
title('Plot B. Frequency each cluster appears in MORC sections')


subplot(4,1,3);
% plot the accuracy of each prediction over all four activities
 aa2 = (aa'+[0.1;0.2;0.3;0.4])'; 
 % add some jitter to each of the four rows, so there is always a unique maximum
 vv = (aa2' == max(aa2'));
 % 4x36 matrix, 0 and 1s, 1 for the max,
 numCC = 4;
 dd = [1:numCC]*vv;
 % dd is the prediction function from kmean clusters to the four activities.
 % which activities it's in. prediction vector dd.
 % we can make it a function, because we need to call it many times.
 % sizedd= size(dd)
 
 CC = dd(C);
 % C is the clustering from the Kmeans, 36 different clusters here.

 c1= hist(CC(1:mathMax),0.5:numCC-0.5);
 c2= hist(CC(mathMax:shutMax),0.5:numCC-0.5);
 c3= hist(CC(shutMax:readMax),0.5:numCC-0.5);
 c4= hist(CC(readMax:length(all)),0.5:numCC-0.5);
 lengthall = length(all)

 ccs = [c1;c2;c3;c4]'./(30*numFiles);
 bar(ccs'); legend('math','shut','read','open');
 grid on;
 grid minor;
 axis([0,5,0,100])
 title('Plot C: Accuracy of k-means classification for each MORC region')


subplot(4,1,4); 
sizeCC = size(CC)
maxCC= max(CC)
zz1 = clusterWindow(CC,windowSize);
sizezz1 = size(zz1)
plot(zz1./(windowSize/100));
%legend(string(1:max(CC)));
legend('math','shut','read','open');
grid on; grid minor;
%xticks([0:3000:12000])
% look into analyzing data using pca(all) to see which
% vectors have the most importance, and cluster on those??
clusters = [1:numClusters];
mathClusters = clusters(vv(1,:)==1);
closedClusters = clusters(vv(2,:)==1);
readClusters = clusters(vv(3,:)==1);
openClusters = clusters(vv(4,:)==1);
title('Plot D: 1 minute smoothing of k-means classification');


maxzz1 = max(zz1')';
sizemaxzz1 = size(maxzz1)
winner = (zz1==maxzz1)*[1;2;3;4];
n = length(math);
accuracyMath = sum(winner(1:n)==1)*100/n
accuracyShut = sum(winner(n+1:2*n)==2)*100/n
accuracyRead = sum(winner(2*n+1:3*n)==3)*100/n
accuracyopen = sum(winner(3*n+1:length(winner))==4)*100/n


%end

