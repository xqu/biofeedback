plotMultiple({'55_2.txt', '55_3.txt', '55_4.txt'},'55_5.txt', 48)

function c=plotMultiple(vectorFile,predictFile, k)
    fileVals=[];
    totalMSRO=0;
    totalMSROForOneFile=0;
    averageMSROForOneFile=[];   
for a=[1:length(vectorFile)]
        % plot the dependence of predication accuracy on k
    filename = predictFile;
    numRuns = 10;
    vals=[];
    maxMSRO=0;
    totalMSROForOneFIle=0;
    for i=[1:numRuns]
        [m,s,r,o,idx,X,sumd,D] = pred_accuracy(vectorFile{a},k);
        msro = min([m,s,r,o]);
        if (msro>maxMSRO)
            maxMSRO = msro;
            maxidx=idx;
            maxX = X;
            maxsumd = sumd;
            maxD =D;
            
        end
        vals = [vals;m s r o msro];
        totalMSROForOneFile=totalMSROForOneFile+msro; 
        
    end 
    bb=totalMSROForOneFile/numRuns;% run average(for one file)
    totalMSROForOneFile=0;
    averageMSROForOneFile=[averageMSROForOneFile,bb];
     
    bb=0;
    
  
     
end 
   c=mean(averageMSROForOneFile); 
    disp(c);
end 